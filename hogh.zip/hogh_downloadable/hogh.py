import pygame
import random as r
import time
import variables as var
import text as Text
import game_tech as gt
import classes as cl

pygame.init()

width = 900
height = 600
window = pygame.display.set_mode((width,height))
pygame.display.set_caption("Hunt or Get Hunted")
icon_path = "icon.png"

icon_surface = pygame.image.load(icon_path)
pygame.display.set_icon(icon_surface)

font = pygame.font.Font('8-bit Arcade In.ttf',90)
font1 = pygame.font.Font('ka1.ttf',30)
font2 = pygame.font.Font('ka1.ttf',35)

#main
running = True
while running:
    var.clock.tick(var.fps)
    window.fill(var.bg)
    #game event
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                var.game_started = True
                var.losed = False
            if event.key == pygame.K_1 and var.game_started and not(var.losed) and not var.chosed:
                var.time_max = 6.8
                var.velocity = 4 
                var.chosed = True
            elif event.key == pygame.K_2 and var.game_started and not(var.losed) and not var.chosed:
                var.time_max = 4.8
                var.velocity = 6
                var.chosed = True
            elif event.key == pygame.K_3 and var.game_started and not(var.losed) and not var.chosed:
                var.time_max = 2.8
                var.velocity = 8
                var.chosed = True
            if var.game_started and not(var.losed) and (event.key == pygame.K_s or event.key == pygame.K_DOWN):
                var.up = False
                var.down = True
                var.left = False
                var.right = False
            elif var.game_started and not(var.losed) and (event.key == pygame.K_w or event.key == pygame.K_UP):
                var.up = True
                var.down = False
                var.left = False
                var.right = False
            elif var.game_started and not(var.losed) and (event.key == pygame.K_a or event.key == pygame.K_LEFT):
                var.up = False
                var.down = False
                var.left = True
                var.right = False
            elif var.game_started and not(var.losed) and (event.key == pygame.K_d  or event.key == pygame.K_RIGHT):
                var.up = False
                var.down = False
                var.left = False
                var.right = True
    #starting
    if not(var.game_started) and not(var.losed):
        Text.menu()
    elif var.losed:
        Text.go()
    elif var.game_started and not(var.losed):
        #mode choosing
        if not(var.chosed):
            gt.mode()
        elif var.chosed:
            #playing
            if not(gt.crash(var.player_pos)) and not(var.losed):
                #timer
                if var.start_time is None:
                    var.start_time = time.time()
                elif time.time() - var.start_time >= var.time_max:
                    gt.game_over()
                    var.starved = True
                if var.start_time is not None:
                    timer_str = "{:.0f}".format(time.time() - var.start_time) 
                else:
                    timer_str = "0"
                text = font1.render(timer_str, True, var.black)
                text1Rect = text.get_rect()
                text1Rect.topright = (width - 10, 5)
                window.blit(text, text1Rect)
                #trap
                if var.traps:
                    var.trap_spawn_rate = r.randint(1,50)
                    var.traps = False
                if var.trap_spawn_rate >= 100:
                    var.food_range = list(var.food_range)
                    var.food_range[0] = var.food_x - abs(var.food_range[2] // 2 - var.food_width // 2)
                    var.food_range[1] = var.food_y - abs(var.food_range[3] // 2 - var.food_height // 2)
                    var.food_range = tuple(var.food_range)
                    var.trap_x = r.randint(var.food_range[0], var.food_range[0] + var.food_range[2])
                    var.trap_y = r.randint(var.food_range[1], var.food_range[1] + var.food_range[3])
                    while (var.trap_x > var.food_x + 50 or var.trap_x < var.food_x - 30) and (var.trap_y > var.food_y + 50 or var.trap_y < var.food_y - 30) and (var.trap_x < width - 850 or var.trap_x > width - 50) and (var.trap_y < height - 550 or var.trap_y > height - 50) and (pygame.Rect(var.trap_x, var.trap_y, 20, 20).colliderect(var.player_pos)):
                        var.trap_x = r.randint(var.food_range[0], var.food_range[0] + var.food_range[2])
                        var.trap_y = r.randint(var.food_range[1], var.food_range[1] + var.food_range[3])
                    if var.trap is None:
                        var.trap = cl.Trap(var.trap_x,var.trap_y)
                    elif var.trap_display_time is None:
                        var.trap.x = var.trap_x
                        var.trap.y = var.trap_y
                        var.trap.hitbox.x = var.trap_x
                        var.trap.hitbox.y = var.trap_y
                        var.trap_display_time = time.time()
                    elif time.time() - var.trap_display_time >= 10:
                        var.trap_display_time = None
                        var.traps = True
                    if var.trap is not None:
                        var.trap.draw(window)
                        if var.trap.check_col(pygame.Rect(var.player_pos)):
                            gt.game_over()
                #enemy
                if not(var.is_enemy_spawned):
                    var.enemy_spawn_rate = r.randint(1,40)
                    var.is_enemy_spawned = True
                if var.enemy_spawn_rate >= 100:
                    var.enemy_x = r.randint(width - 850, width - 50)
                    var.enemy_y = r.randint(height - 550, height - 50)
                    player_pos_check = var.player_pos
                    player_pos_check = list(player_pos_check)
                    player_pos_check[0] += 100
                    player_pos_check[1] += 100
                    player_pos_check = tuple(player_pos_check)
                    while (pygame.Rect(var.enemy_x, var.enemy_y, 20, 20).colliderect(var.player_pos) or pygame.Rect(var.enemy_x, var.enemy_y, 20, 20).colliderect(var.trap.hitbox)) and (var.enemy_x > player_pos_check[0] or var.enemy_x < player_pos_check[0] - 160) and (var.enemy_y > player_pos_check[1] or var.enemy_y < player_pos_check[1] - 160):
                        var.enemy_x = r.randint(width - 850, width - 50)
                        var.enemy_y = r.randint(height - 550, height - 50)
                    if var.enemy is None:
                        var.enemy = cl.Enemy(var.enemy_x,var.enemy_y)
                    elif var.enemy_display_time is None:
                        var.enemy.color = var.white
                        var.enemy_range = list(var.enemy_range)
                        var.enemy_range[0] = var.enemy_x - abs(var.enemy_range[2] // 2 - var.enemy.width // 2)
                        var.enemy_range[1] = var.enemy_y - abs(var.enemy_range[3] // 2 - var.enemy.height // 2)
                        var.enemy_range = tuple(var.enemy_range)
                        var.enemy.x = var.enemy_x
                        var.enemy.y = var.enemy_y
                        var.enemy.hitbox.x = var.enemy_x
                        var.enemy.hitbox.y = var.enemy_y
                        var.enemy_turned = False
                        var.enemy_display_time = time.time()
                    elif time.time() - var.enemy_display_time >= 5:
                        var.enemy_display_time = None
                        var.is_enemy_spawned = False
                        var.food_spawn = True
                        var.enemy = None
                    if var.enemy is not None:
                        if pygame.Rect(var.player_pos).colliderect(pygame.Rect(var.enemy_range)):
                            var.enemy_turned = True
                        if not var.enemy_turned:
                            var.food_spawn = False
                            var.enemy.color = var.red
                        elif var.enemy_turned:
                            var.food_spawn = True
                            var.enemy.color = var.black
                            var.enemy.chase(var.player_pos)
                        var.enemy.draw(window, var.enemy.color)
                        if var.enemy.check_col(pygame.Rect(var.player_pos)):
                            gt.game_over()
                            var.ambushed = True
                #player
                var.player_pos = (var.move_x, var.move_y,40,40)
                pygame.draw.rect(window, var.black, var.player_pos)
                if var.food_spawn:
                    if var.eaten:
                        pygame.draw.rect(window, var.red, var.food_pos)
                        var.drawed = True
                    if not(var.drawed):
                        pygame.draw.rect(window, var.red, var.food_pos)
                    gt.point(pygame.Rect(var.player_pos),pygame.Rect(var.food_pos))
                if var.eaten:
                    var.start_time = None
                pygame.draw.rect(window, var.black, var.player_pos)
                Text.point_counter()
                if var.up:
                    var.move_y -= var.velocity
                elif var.down: 
                    var.move_y += var.velocity
                elif var.right:
                    var.move_x += var.velocity
                elif var.left:
                    var.move_x -= var.velocity
            elif (gt.crash(var.player_pos) and var.game_started) or (var.losed):
                gt.game_over()
                var.killed_by_poison = True

    pygame.display.update()
    pygame.display.flip()
pygame.quit()
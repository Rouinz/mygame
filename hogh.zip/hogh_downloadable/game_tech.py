import variables as var
import random as r

black = var.black
font2 = var.font2
width = var.width
height = var.height
window = var.window

def crash(player_pos):
    player_left = player_pos[0]
    player_top = player_pos[1]
    player_right = player_pos[0] + player_pos[2]
    player_bottom = player_pos[1] + player_pos[3]

    if player_top <= 0 or player_bottom >= 600 or player_left <= 0 or player_right >= 900:
        return True
    return False

def game_over():
    var.ambushed = False
    var.start_time = None
    var.starved = False
    var.s = ""
    var.killed_by_poison = False
    var.enemy_turned = False
    var.losed = True
    var.game_started = False
    if var.high_score <= var.score:
        var.high_score = var.score
    var.old_score = var.score
    var.score = 0
    var.move_x = var.width // 2
    var.move_y = var.height // 2
    var.player_pos = (var.move_x, var.move_y, 40, 40)
    var.food_x = r.randint(var.width - 850, var.width - 50)
    var.food_y = r.randint(var.height - 550, var.height - 50)
    var.food_pos = (var.food_x, var.food_y,20,20)
    var.trap_x = 0
    var.trap_y = 0
    var.up = True
    var.down = False
    var.left = False
    var.right = False
    var.chosed = False
    var.trap_spawn_rate = 0
    var.traps = True
    var.enemy_spawn_rate = 0
    var.enemy_x = 0
    var.enemy_y = 0
    var.is_enemy_spawned = False
    var.enemy = None
    var.food_spawn = True

def point(player,food):
    if player.colliderect(food) and var.eaten == False and var.food_spawn:
        var.score += 1
        var.eaten = True
        var.food_x = r.randint(var.width - 850, var.width - 50)
        var.food_y = r.randint(var.height - 550, var.height - 50)
        var.food_pos = (var.food_x, var.food_y, 20, 20)
        var.trap_spawn_rate += r.randint(10,20)
        var.enemy_spawn_rate += r.randint(10,15)
        var.velocity += var.velocity_list[r.randint(0,2)]
    else:
        var.eaten = False
    return var.score
def mode():
    easy = font2.render("Easy Mode - Press 1", True, black)
    easyRect = easy.get_rect()
    easyRect.center = (width // 2, height // 2 - 100)
    window.blit(easy, easyRect)
    normal = font2.render("Normal Mode - Press 2", True, black)
    normalRect = normal.get_rect()
    normalRect.center = (width // 2, height // 2)
    window.blit(normal, normalRect)
    hard = font2.render("Hard Mode - Press 3", True, black)
    hardRect = hard.get_rect()
    hardRect.center = (width // 2, height // 2 + 100)
    window.blit(hard, hardRect)
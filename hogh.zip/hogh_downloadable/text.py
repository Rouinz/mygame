import pygame
import variables as var
import game_tech as gt

font = var.font
font1 = var.font1
font2 = var.font2
ver_font = var.ver_font
width = var.width
height = var.height
window = pygame.display.set_mode((width,height))
black = var.black
player_pos = var.player_pos
food_pos = var.food_pos

def menu():
    title1 = font.render("Hunt or Get Hunted", True, black)
    title2 = font1.render("Press Spacebar to play", True, black)
    version = ver_font.render("Ver 1.0", True, black)
    title1Rect = title1.get_rect()
    title2Rect = title2.get_rect()
    versionRect = version.get_rect()
    title1Rect.center = (width // 2, height // 2 - 50)
    title2Rect.center = (width // 2, height // 2 + 70)
    versionRect.center = (820, height // 2)
    window.blit(title1, title1Rect)
    window.blit(title2, title2Rect)
    window.blit(version, versionRect)
def go():
    over = font2.render("Game Over!", True, black)
    if var.killed_by_poison:
        s = "You got poisoned to death"
    elif var.starved:
        s = "You starved to death"
    elif var.ambushed:
        s = "You got ambushed"
    else:
        s = "You stepped on a trap"
    reason = font2.render(s, True, black)
    result = font2.render("Your Score: ", True,black)
    result1 = font2.render(str(var.old_score), True, black)
    high_sc = font2.render("High Score: ", True, black)
    high_sc2 = font2.render(str(var.high_score), True, black)
    overRect = over.get_rect()
    reasonRect = reason.get_rect()
    resultRect = result.get_rect()
    result1Rect = result1.get_rect()
    high_scRect = high_sc.get_rect()
    high_sc2Rect = high_sc2.get_rect()
    overRect.center = (width // 2, 100)
    reasonRect.center = (width//2, 150)
    resultRect.center = (width // 2, 360)
    result1Rect.center = (width // 2, 400)
    high_scRect.center = (width // 2, 250)
    high_sc2Rect.center = (width // 2, 290)
    window.blit(over, overRect)
    window.blit(reason, reasonRect)
    window.blit(result, resultRect)
    window.blit(result1, result1Rect)
    window.blit(high_sc, high_scRect)
    window.blit(high_sc2, high_sc2Rect)
def point_counter():
    text = font1.render("Score: "+str(gt.point(pygame.Rect(player_pos),pygame.Rect(food_pos))), True, black)
    textRect = text.get_rect()
    textRect.topleft = (10,5)
    window.blit(text, textRect)
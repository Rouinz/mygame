import pygame
import random as r

pygame.init()

width = 900
height = 600
window = pygame.display.set_mode((width,height))
#fonts
font = pygame.font.Font('8-bit Arcade In.ttf',90)
font1 = pygame.font.Font('ka1.ttf',30)
font2 = pygame.font.Font('ka1.ttf',35)
ver_font = pygame.font.Font('ka1.ttf',25)
#colors
blue = (0,0,255)
white = (255,255,255)
black = (0,0,0)
red = (255,0,0)
bg = (255,255,255)
#fps
fps = 90
clock = pygame.time.Clock()
#movement
move_x = width//2
move_y = height//2
player_pos = (move_x,move_y,40,40)
velocity = 3
old_velocity = 0
is_pressed = False
up = True
down = False
left = False
right = False
eaten = False
velocity_list = [0.05,0.1,0.03]
#food
food_x = r.randint(width - 850, width - 50)
food_y = r.randint(height - 550, height - 50)
food_pos = (food_x,food_y,20,20)
drawed = False
food_range = (food_x, food_y, 250, 250)
food_height = 20
food_width = 20
#trap
trap = None
traps = True
trap_x = -100
trap_y = -100
trap_display_time = None
trap_spawn_rate = 0
is_spawned = False
food_spawn = True
#enemy
is_enemy_spawned = False
enemy_spawn_rate = 0
enemy_x = -100
enemy_y = -100
enemy_display_time = None
enemy = None
enemy_turned = False
enemy_range = (enemy_x,enemy_y, 200, 200)
ambushed = False
#score
s = ""
game_started = False
losed = False
score = 0
old_score = 0
chosed = False
high_score = 0
killed_by_poison = False
starved = False
#timer
start_time = None
time_max = 0
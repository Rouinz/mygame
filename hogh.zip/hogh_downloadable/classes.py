import pygame
import math
import variables as var

class Trap:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.width = 20
        self.height = 20
        self.color = var.white
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height)
    def draw(self, window):
        pygame.draw.rect(window, var.blue, self.hitbox)
    def check_col(self,other_rect):
        return self.hitbox.colliderect(other_rect)
class Enemy:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.width = 20
        self.height = 20
        self.hitbox = pygame.Rect(self.x, self.y, self.width, self.height)
    def draw(self,window,color):
        pygame.draw.rect(window, self.color, self.hitbox)
        self.color = color
    def check_col(self,other_rect):
        return self.hitbox.colliderect(other_rect)
    def chase(self,player_pos):
        dx = player_pos[0] - self.x
        dy = player_pos[1] - self.y
        distance = math.sqrt(dx**2 + dy**2)
        if distance != 0:
            dx_normalized = dx / distance
            dy_normalized = dy / distance
            self.x += dx_normalized * (var.velocity-3.87)
            self.y += dy_normalized * (var.velocity-3.87)

            self.hitbox.x = self.x
            self.hitbox.y = self.y